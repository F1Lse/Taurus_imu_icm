#ifndef __CAN_COMM_H
#define __CAN_COMM_H

#include "stm32g4xx.h"

void can_comm_init(void);
uint8_t can_std_transmit(FDCAN_HandleTypeDef *hfdcan, uint32_t id, uint8_t *data);


#endif
