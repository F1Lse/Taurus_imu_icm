/**
	* @file Calibration.c
	* @version 1.0
	* @date 2019.12.1
  *
  * @brief  ��ƫУ׼����
  *
  *	@author YY(Part of codes reference ��������)
  *
  */

#include "Calibration.h"
#include "pid.h"
#define ABS(x)		((x>0)? (x): (-x))

float AccRatioOffset;
void BMI088_Calibration()
{

}


